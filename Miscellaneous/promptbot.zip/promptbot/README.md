# PromptBot — AI Chatbot with Prompt Engineering

A conversational AI chatbot demonstrating structured prompt engineering techniques.
Built with Python (Flask) backend + HTML/CSS/JS frontend + Anthropic Claude API.

---

## 📁 Project Structure

```
promptbot/
├── app.py                 ← Flask server (API routes + prompt logic)
├── requirements.txt       ← Python dependencies
├── README.md              ← This file
├── templates/
│   └── index.html         ← Chat UI
└── static/
    ├── style.css          ← Styles
    └── script.js          ← Frontend logic
```

---

## ✅ Requirements

- Python 3.8 or higher
- pip (Python package manager)
- An Anthropic API key → https://console.anthropic.com

---

## 🚀 How to Run (Step by Step)

### Step 1 — Install Python dependencies

Open a terminal in the `promptbot/` folder and run:

```bash
pip install -r requirements.txt
```

---

### Step 2 — Set your Anthropic API key

Get your key from: https://console.anthropic.com → API Keys → Create Key

**Mac / Linux:**
```bash
export ANTHROPIC_API_KEY="sk-ant-your-key-here"
```

**Windows (Command Prompt):**
```cmd
set ANTHROPIC_API_KEY=sk-ant-your-key-here
```

**Windows (PowerShell):**
```powershell
$env:ANTHROPIC_API_KEY="sk-ant-your-key-here"
```

> Alternatively, open `app.py` and replace line 14 with:
> ```python
> client = anthropic.Anthropic(api_key="sk-ant-your-key-here")
> ```

---

### Step 3 — Start the server

```bash
python app.py
```

You should see:
```
✅ PromptBot is running!
👉 Open http://localhost:5000 in your browser
```

---

### Step 4 — Open in browser

Go to: **http://localhost:5000**

---

## 🎯 Features

| Feature | Description |
|---|---|
| 5 Prompt Modes | General, Explain, Code Helper, Concise, Creative |
| Prompt Engineering | Each mode uses a different structured system prompt |
| Conversation History | Full multi-turn context maintained per session |
| Clear Chat | Reset conversation with one click |
| Keyboard Shortcut | Enter to send, Shift+Enter for new line |

## 🧠 Prompt Engineering Techniques Used

- **System prompt design** — each mode has a distinct system prompt controlling tone, format, length
- **Output format control** — Explain mode enforces a 3-part structure (summary, explanation, analogy)
- **Constraint prompting** — Concise mode hard-limits to 1-2 sentences
- **Persona prompting** — Creative mode uses personality-based prompting
- **Conversation history** — full history passed each turn for contextual multi-turn responses

---

## ❓ Troubleshooting

| Problem | Fix |
|---|---|
| `ModuleNotFoundError` | Run `pip install -r requirements.txt` again |
| `AuthenticationError` | Check your API key is set correctly |
| Page not loading | Make sure `python app.py` is running and use `http://localhost:5000` |
| Port already in use | Change `port=5000` to `port=5001` in `app.py` |
