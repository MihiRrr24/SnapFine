# PromptBot 🤖

A lightweight chatbot web app powered by **Google Gemini** (free tier), built with Flask and plain HTML/JS. Supports multiple prompt modes to demonstrate structured prompt engineering.

---

## Features

- 💬 Multi-turn conversation with memory
- 🎛️ 5 prompt modes: General, Explain, Code, Concise, Creative
- ⚡ Powered by Gemini 1.5 Flash (free, no credit card needed)
- 🧪 Great for learning prompt engineering

---

## Setup

### 1. Get a free Gemini API key

1. Go to [https://aistudio.google.com](https://aistudio.google.com)
2. Sign in with your Google account
3. Click **Get API key** → **Create API key**
4. Copy the key

### 2. Install dependencies

```bash
pip install -r requirements.txt
```

### 3. Set your API key

**Windows (PowerShell):**
```powershell
$env:GEMINI_API_KEY = "your-key-here"
```

**Windows (Command Prompt):**
```cmd
set GEMINI_API_KEY=your-key-here
```

**Mac/Linux:**
```bash
export GEMINI_API_KEY="your-key-here"
```

> 💡 **Tip:** Create a `.env` file so you don't have to set it every time (see below).

### 4. Run the app

```bash
python app.py
```

Then open [http://localhost:5000](http://localhost:5000) in your browser.

---

## Using a .env file (recommended)

Install python-dotenv:
```bash
pip install python-dotenv
```

Create a `.env` file in the project folder:
```
GEMINI_API_KEY=your-key-here
```

Add these two lines to the top of `app.py`:
```python
from dotenv import load_dotenv
load_dotenv()
```

Add `.env` to your `.gitignore` — **never commit your API key**.

---

## Prompt Modes

| Mode | Description |
|------|-------------|
| **General** | Friendly, conversational answers |
| **Explain** | Structured: Summary → Explanation → Analogy |
| **Code** | Approach + clean commented code snippet |
| **Concise** | 1-2 sentence answers only |
| **Creative** | Witty, playful, fun responses |

---

## Project Structure

```
promptbot/
├── app.py              # Flask backend
├── requirements.txt    # Python dependencies
├── templates/
│   └── index.html      # Chat UI
└── static/
    ├── style.css
    └── script.js
```

---

## Switching Models

In `app.py`, you can change the model name:

```python
model_name="gemini-1.5-flash"    # Fast, free
model_name="gemini-1.5-pro"      # Smarter, still free tier
model_name="gemini-2.0-flash"    # Latest fast model
```

---

## License

MIT
