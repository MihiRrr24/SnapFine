from dotenv import load_dotenv
load_dotenv()

from flask import Flask, request, jsonify, render_template
from flask_cors import CORS
import google.generativeai as genai
import os

app = Flask(__name__)
CORS(app)

genai.configure(api_key=os.environ.get("GEMINI_API_KEY"))

MODES = {
    "general": (
        "You are PromptBot, a helpful and friendly general-purpose assistant. "
        "Answer questions clearly and conversationally. Keep responses to 2-4 sentences "
        "unless the question genuinely requires more detail."
    ),
    "explain": (
        "You are PromptBot in Explainer Mode. For EVERY answer, you MUST follow this exact structure:\n"
        "1) Summary: One-line plain summary of the answer\n"
        "2) Explanation: A clear explanation in simple English\n"
        "3) Analogy: A real-world analogy to make it stick\n"
        "Always use these three labeled sections."
    ),
    "code": (
        "You are PromptBot in Code Helper mode. For every response:\n"
        "- Start with a short explanation of the approach (2-3 sentences)\n"
        "- Then provide a clean, well-commented code snippet\n"
        "- Default to Python unless another language is specified\n"
        "Keep code concise and beginner-friendly."
    ),
    "concise": (
        "You are PromptBot in Concise Mode. "
        "Reply in 1-2 sentences MAXIMUM. "
        "No preamble, no filler, no 'Great question!'. "
        "Just the direct answer."
    ),
    "creative": (
        "You are PromptBot in Creative Mode — witty, playful, and fun. "
        "Use humor, clever metaphors, and creative angles in your responses. "
        "Be genuinely helpful, but make it entertaining to read."
    ),
}


@app.route("/")
def index():
    return render_template("index.html")


@app.route("/chat", methods=["POST"])
def chat():
    data = request.get_json()

    user_message = data.get("message", "").strip()
    mode = data.get("mode", "general")
    history = data.get("history", [])

    if not user_message:
        return jsonify({"error": "Message cannot be empty"}), 400

    system_prompt = MODES.get(mode, MODES["general"])

    # Convert history: Anthropic uses "assistant", Gemini uses "model"
    gemini_history = []
    for msg in history:
        role = "model" if msg["role"] == "assistant" else "user"
        gemini_history.append({"role": role, "parts": msg["content"]})

    try:
        model = genai.GenerativeModel(
            model_name="gemini-2.5-flash",  # <-- Change to gemini-2.5-flash
            system_instruction=system_prompt
        )
        chat_session = model.start_chat(history=gemini_history)
        response = chat_session.send_message(user_message)
        reply = response.text
        return jsonify({"reply": reply})

    except Exception as e:
        return jsonify({"error": str(e)}), 500


if __name__ == "__main__":
    print("\n✅ PromptBot is running!")
    print("👉 Open http://localhost:5000 in your browser\n")
    app.run(debug=True, port=5000)