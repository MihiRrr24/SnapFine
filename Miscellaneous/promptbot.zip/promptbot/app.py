from flask import Flask, request, jsonify, render_template
from flask_cors import CORS
import anthropic
import os

app = Flask(__name__)
CORS(app)

# ─── API KEY SETUP ───────────────────────────────────────────────
# Option 1: Set env variable before running:
#   Mac/Linux:  export ANTHROPIC_API_KEY="sk-ant-..."
#   Windows:    set ANTHROPIC_API_KEY=sk-ant-...
#
# Option 2: Paste your key directly here (not recommended for sharing):
#   ANTHROPIC_API_KEY = "sk-ant-your-key-here"
# ─────────────────────────────────────────────────────────────────

client = anthropic.Anthropic(api_key=os.environ.get("ANTHROPIC_API_KEY"))

# Structured system prompts — the core prompt engineering
MODES = {
    "general": (
        "You are PromptBot, a helpful and friendly general-purpose assistant. "
        "Answer questions clearly and conversationally. Keep responses to 2-4 sentences "
        "unless the question genuinely requires more detail."
    ),
    "explain": (
        "You are PromptBot in Explainer Mode. For EVERY answer, you MUST follow this exact structure:\n"
        "1) Summary: One-line plain summary of the answer\n"
        "2) Explanation: A clear explanation in simple English\n"
        "3) Analogy: A real-world analogy to make it stick\n"
        "Always use these three labeled sections."
    ),
    "code": (
        "You are PromptBot in Code Helper mode. For every response:\n"
        "- Start with a short explanation of the approach (2-3 sentences)\n"
        "- Then provide a clean, well-commented code snippet\n"
        "- Default to Python unless another language is specified\n"
        "Keep code concise and beginner-friendly."
    ),
    "concise": (
        "You are PromptBot in Concise Mode. "
        "Reply in 1-2 sentences MAXIMUM. "
        "No preamble, no filler, no 'Great question!'. "
        "Just the direct answer."
    ),
    "creative": (
        "You are PromptBot in Creative Mode — witty, playful, and fun. "
        "Use humor, clever metaphors, and creative angles in your responses. "
        "Be genuinely helpful, but make it entertaining to read."
    ),
}


@app.route("/")
def index():
    return render_template("index.html")


@app.route("/chat", methods=["POST"])
def chat():
    data = request.get_json()

    user_message = data.get("message", "").strip()
    mode = data.get("mode", "general")
    history = data.get("history", [])  # list of {role, content}

    if not user_message:
        return jsonify({"error": "Message cannot be empty"}), 400

    system_prompt = MODES.get(mode, MODES["general"])

    # Build full message list: history + new user message
    messages = history + [{"role": "user", "content": user_message}]

    response = client.messages.create(
        model="claude-sonnet-4-20250514",
        max_tokens=1000,
        system=system_prompt,
        messages=messages,
    )

    reply = response.content[0].text
    return jsonify({"reply": reply})


if __name__ == "__main__":
    print("\n✅ PromptBot is running!")
    print("👉 Open http://localhost:5000 in your browser\n")
    app.run(debug=True, port=5000)
