// ── State ──────────────────────────────────────────────────
const MODE_LABELS = {
  general:  "General Assistant",
  explain:  "Explainer Mode",
  code:     "Code Helper",
  concise:  "Concise Mode",
  creative: "Creative Mode",
};

let currentMode = "general";
let history     = [];   // [{ role: "user"|"assistant", content: "..." }]
let busy        = false;

// ── Elements ───────────────────────────────────────────────
const messagesEl    = document.getElementById("messages");
const inputEl       = document.getElementById("user-input");
const sendBtn       = document.getElementById("send-btn");
const modeLabelEl   = document.getElementById("current-mode-label");
const clearBtn      = document.getElementById("clear-btn");

// ── Mode switching ─────────────────────────────────────────
document.querySelectorAll(".mode-btn").forEach(btn => {
  btn.addEventListener("click", () => {
    document.querySelectorAll(".mode-btn").forEach(b => b.classList.remove("active"));
    btn.classList.add("active");
    currentMode = btn.dataset.mode;
    modeLabelEl.textContent = MODE_LABELS[currentMode];
    history = [];
    appendMessage("bot", `Switched to ${MODE_LABELS[currentMode]}.\nConversation history cleared — fresh start!`);
  });
});

// ── Clear chat ─────────────────────────────────────────────
clearBtn.addEventListener("click", () => {
  history = [];
  messagesEl.innerHTML = "";
  appendMessage("bot", "Chat cleared. Ask me anything!");
});

// ── Input handlers ─────────────────────────────────────────
inputEl.addEventListener("keydown", e => {
  if (e.key === "Enter" && !e.shiftKey) {
    e.preventDefault();
    sendMessage();
  }
});

inputEl.addEventListener("input", () => {
  inputEl.style.height = "auto";
  inputEl.style.height = Math.min(inputEl.scrollHeight, 140) + "px";
});

sendBtn.addEventListener("click", sendMessage);

// ── Core: send message to Flask backend ───────────────────
async function sendMessage() {
  const text = inputEl.value.trim();
  if (!text || busy) return;

  // Reset input
  inputEl.value = "";
  inputEl.style.height = "auto";
  busy = true;
  sendBtn.disabled = true;

  // Show user message
  appendMessage("user", text);

  // Add to history BEFORE sending (so backend gets full context)
  history.push({ role: "user", content: text });

  // Show typing indicator
  showTyping();

  try {
    const response = await fetch("/chat", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        message: text,
        mode: currentMode,
        history: history.slice(0, -1), // send history without the current message (backend adds it)
      }),
    });

    const data = await response.json();
    removeTyping();

    if (data.error) {
      appendMessage("bot", "⚠ Error: " + data.error);
    } else {
      appendMessage("bot", data.reply);
      history.push({ role: "assistant", content: data.reply });

      // Keep history from growing too large (last 20 turns)
      if (history.length > 20) history = history.slice(-20);
    }

  } catch (err) {
    removeTyping();
    appendMessage("bot", "⚠ Could not reach the server.\nMake sure app.py is running on localhost:5000");
    console.error(err);
  }

  busy = false;
  sendBtn.disabled = false;
  inputEl.focus();
}

// ── DOM helpers ────────────────────────────────────────────
function appendMessage(role, text) {
  const isUser = role === "user";

  const wrap = document.createElement("div");
  wrap.className = "msg " + (isUser ? "user" : "bot");

  const av = document.createElement("div");
  av.className = "av";
  av.textContent = isUser ? "You" : "PB";

  const bubble = document.createElement("div");
  bubble.className = "bubble";
  bubble.textContent = text;

  wrap.appendChild(av);
  wrap.appendChild(bubble);
  messagesEl.appendChild(wrap);
  messagesEl.scrollTop = messagesEl.scrollHeight;
}

function showTyping() {
  const wrap = document.createElement("div");
  wrap.className = "msg bot";
  wrap.id = "typing-indicator";

  const av = document.createElement("div");
  av.className = "av";
  av.textContent = "PB";

  const bubble = document.createElement("div");
  bubble.className = "bubble";
  bubble.innerHTML = '<div class="typing"><div class="dot"></div><div class="dot"></div><div class="dot"></div></div>';

  wrap.appendChild(av);
  wrap.appendChild(bubble);
  messagesEl.appendChild(wrap);
  messagesEl.scrollTop = messagesEl.scrollHeight;
}

function removeTyping() {
  const t = document.getElementById("typing-indicator");
  if (t) t.remove();
}
